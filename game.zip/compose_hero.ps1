Add-Type -AssemblyName System.Drawing
$imgPath = "e:\Kouhei\RenPy\renpy-8.3.6-sdk\Test\Test1\Record of battling illness\hospital_staff_original.jpg"
$destPath = "e:\Kouhei\RenPy\renpy-8.3.6-sdk\Test\Test1\Record of battling illness\hero_banner_crop_local.png"

$img = [System.Drawing.Image]::FromFile($imgPath)

# クロップ元の範囲設定 (上から5%〜63%付近、看板から胸元まで)
$cropY = [int]($img.Height * 0.05)
$cropHeight = [int]($img.Height * 0.58)
$cropWidth = $img.Width

# 出力バナーサイズ (1020 x 440)
$bannerWidth = 1020
$bannerHeight = 440

$bmp = new-object System.Drawing.Bitmap($bannerWidth, $bannerHeight)
$g = [System.Drawing.Graphics]::FromImage($bmp)

# 描画品質の設定
$g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality

# 1. 背景描画 (元の画像を引き延ばして全面に描き、白半透明でぼかす効果を演出)
$srcRectBg = new-object System.Drawing.Rectangle(0, $cropY, $cropWidth, $cropHeight)
$destRectBg = new-object System.Drawing.Rectangle(0, 0, $bannerWidth, $bannerHeight)
$g.DrawImage($img, $destRectBg, $srcRectBg, [System.Drawing.GraphicsUnit]::Pixel)

# 白の半透明レイヤーを重ねる (元の背景を明るくフェードアウトさせる)
$brush = new-object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(220, 255, 255, 255))
$g.FillRectangle($brush, 0, 0, $bannerWidth, $bannerHeight)

# 2. 中央に比率を維持した鮮明な画像を描画
$centerHeight = $bannerHeight
$centerWidth = [int]($centerHeight * ($cropWidth / $cropHeight))
$centerX = [int](($bannerWidth - $centerWidth) / 2)

$destRectCenter = new-object System.Drawing.Rectangle($centerX, 0, $centerWidth, $centerHeight)
$g.DrawImage($img, $destRectCenter, $srcRectBg, [System.Drawing.GraphicsUnit]::Pixel)

# 3. 境界線フェード効果の追加 (LinearGradientBrush を用いて左右の境界を背景とソフトに馴染ませる)
$fadeWidth = 50
# 左境界のフェード (不透明から透明へ)
$rectLeft = new-object System.Drawing.Rectangle($centerX, 0, $fadeWidth, $bannerHeight)
$colorLeftStart = [System.Drawing.Color]::FromArgb(220, 255, 255, 255)
$colorLeftEnd = [System.Drawing.Color]::FromArgb(0, 255, 255, 255)
$brushLeft = new-object System.Drawing.Drawing2D.LinearGradientBrush($rectLeft, $colorLeftStart, $colorLeftEnd, 0.0)
$g.FillRectangle($brushLeft, $rectLeft)
$brushLeft.Dispose()

# 右境界のフェード (透明から不透明へ)
$rectRight = new-object System.Drawing.Rectangle(($centerX + $centerWidth - $fadeWidth), 0, $fadeWidth, $bannerHeight)
$colorRightStart = [System.Drawing.Color]::FromArgb(0, 255, 255, 255)
$colorRightEnd = [System.Drawing.Color]::FromArgb(220, 255, 255, 255)
$brushRight = new-object System.Drawing.Drawing2D.LinearGradientBrush($rectRight, $colorRightStart, $colorRightEnd, 0.0)
$g.FillRectangle($brushRight, $rectRight)
$brushRight.Dispose()

# 保存
$bmp.Save($destPath, [System.Drawing.Imaging.ImageFormat]::Png)

$brush.Dispose()
$g.Dispose()
$bmp.Dispose()
$img.Dispose()
write-output "Advanced Compose with Gradients completed successfully."
