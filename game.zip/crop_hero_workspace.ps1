Add-Type -AssemblyName System.Drawing
$imgPath = "e:\Kouhei\RenPy\renpy-8.3.6-sdk\Test\Test1\Record of battling illness\hospital_staff_original.jpg"
$destPath = "e:\Kouhei\RenPy\renpy-8.3.6-sdk\Test\Test1\Record of battling illness\hero_banner_crop_local.png"

$img = [System.Drawing.Image]::FromFile($imgPath)
$y = [int]($img.Height * 0.05) # 上から5%の位置
$height = [int]($img.Height * 0.58) # 看板から医師の胸元まで

$bmp = new-object System.Drawing.Bitmap($img.Width, $height)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$srcRect = new-object System.Drawing.Rectangle(0, $y, $img.Width, $height)
$destRect = new-object System.Drawing.Rectangle(0, 0, $img.Width, $height)
$g.DrawImage($img, $destRect, $srcRect, [System.Drawing.GraphicsUnit]::Pixel)

$bmp.Save($destPath, [System.Drawing.Imaging.ImageFormat]::Png)

$g.Dispose()
$bmp.Dispose()
$img.Dispose()
write-output "Crop completed in workspace successfully."
