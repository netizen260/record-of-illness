# ==========================================
# 桜吹雪（パーティクル）の定義
# ==========================================

# --- 1. 背面用（人物の奥に表示） ---
image sakura_back = Fixed(
    SnowBlossom(Transform("images/fx/sakura01.png", rotate=30, zoom=0.7), count=40, border=50, xspeed=(10, 25), yspeed=(60, 100), fast=True),
    SnowBlossom(Transform("images/fx/sakura02.png", rotate=-15, zoom=0.6), count=40, border=50, xspeed=(10, 25), yspeed=(60, 100), fast=True),
    SnowBlossom(Transform("images/fx/sakura03.png", rotate=45, zoom=0.8), count=40, border=50, xspeed=(10, 25), yspeed=(60, 100), fast=True)
)

# --- 2. 前面用（人物の手前に表示） ---
image sakura_front = Fixed(
    SnowBlossom(Transform("images/fx/sakura01.png", rotate=0, zoom=1.2), count=16, border=50, xspeed=(20, 50), yspeed=(120, 220), fast=True),
    SnowBlossom(Transform("images/fx/sakura02.png", rotate=45, zoom=1.0), count=17, border=50, xspeed=(20, 50), yspeed=(120, 220), fast=True),
    SnowBlossom(Transform("images/fx/sakura03.png", rotate=-30, zoom=1.1), count=17, border=50, xspeed=(20, 50), yspeed=(120, 220), fast=True)
)

# ※補足：RotoZoomを使うことで、花びらにランダムな回転とサイズ変化を与え、
# 単一の画像でも「違うイラスト」に見せる効果を高めています。