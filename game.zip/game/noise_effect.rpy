# noise_effect.rpy

init python:
    renpy.register_shader("custom.sandstorm",
        variables="""
            uniform float u_time;
        """,
        fragment_functions="""
            float rand(vec2 co, float time){
                return fract(sin(dot(co.xy + time, vec2(12.9898,78.233))) * 43758.5453);
            }
        """,
        fragment_300="""
            float noise = rand(gl_FragCoord.xy, u_time * 10.0);
            gl_FragColor = vec4(noise, noise, noise, 1.0);
        """
    )

# 砂嵐のエフェクトを適用するTransform
transform sandstorm_shader:
    shader "custom.sandstorm"

# 画面全体に砂嵐を表示するためのImage
image sandstorm_bg = Transform(Solid("#000"), shader="custom.sandstorm")

# 自動入力演出用のスクリーン
screen auto_input_screen(prompt_text, text_to_type):
    default typed_text = ""
    default char_index = 0
    
    # 0.2秒ごとに1文字ずつ追加するタイマー
    timer 0.15 repeat True action [
        If(char_index < len(text_to_type),
            true=[
                SetScreenVariable("typed_text", typed_text + text_to_type[char_index:char_index+1]),
                SetScreenVariable("char_index", char_index + 1)
            ],
            false=NullAction()
        )
    ]
    
    vbox:
        align (0.5, 0.5)
        text prompt_text size 30 color "#ffffff" xalign 0.5
        null height 20
        # 入力枠のような背景
        frame:
            xalign 0.5
            xysize (400, 60)
            background Solid("#222222")
            text typed_text + (If(char_index < len(text_to_type), "_", "")) size 35 color "#00ff00" align (0.5, 0.5)

# システムローディング用のスクリーン
screen fake_loading_screen(duration=2.5):
    default progress = 0.0
    
    # 少しずつ進むプログレスバー
    timer 0.05 repeat True action [
        If(progress < 100.0,
            true=SetScreenVariable("progress", min(100.0, progress + (100.0 / (duration / 0.05)))),
            false=Return() # 100%になったら自動的に画面を閉じて次へ進む
        )
    ]
    
    vbox:
        align (0.5, 0.5)
        text "SYSTEM OVERRIDE IN PROGRESS... [int(progress)]%" size 30 color "#00ff00" xalign 0.5
        null height 15
        bar:
            value progress
            range 100.0
            xysize (500, 25)
            xalign 0.5
            left_bar Solid("#00ff00")
            right_bar Solid("#333333")
