# このファイルにはゲームのシステム定義と初期設定を記述します。
# 実際のシナリオは「script_part1.rpy」「script_part2.rpy」「script_part3.rpy」に分割されています。

init python:
    import webbrowser

# ==========================================
# キャラクターの定義
# ==========================================
define s = Character('しおり')
define m = Character("player_name", dynamic=True, color="#ffffff")
define r = Character('レイ', color="#88aadd")
define n = Character('？？？', color="#aaaaaa")
define k = Character('看護師', color="#cccccc")
define sakura_char = Character('佐倉院長', color="#ddaa88")
define sys = Character('SYSTEM')
# 第3部：ターミナル風キャラクター定義
define admin_01 = Character('[[ADMIN-01]]', who_color="#aaffaa", what_color="#00ff41")
define sys_red = Character('[[SYSTEM]]', who_color="#ff4444", what_color="#ff8888")

# ==========================================
# 変数・フラグの定義
# ==========================================
# UIのフェーズを管理するフラグ（1: 初期, 2: phase2, 3: phase3）
default ui_phase = 1
default player_name = "主人公"
default badpoint = 0

define ps_center = Position(xpos=0.5, ypos=0.75)

# ==========================================
# 画像・エフェクトの定義は assets.rpy に移動しました
# ==========================================

# ==========================================
# 共通スクリーン定義
# ==========================================
# ブラウザ起動用のスクリーン
screen browser_link():
    vbox:
        align (0.5, 0.7)
        textbutton "Bloggerを確認する":
            action Function(webbrowser.open, "https://sakurahospital.blogspot.com/")
            text_size 40
            text_color "#00ff00"
            text_hover_color "#ffffff"

# 第3部専用：コラージュ背景上に表示するリンクボタン
screen browser_link_hacker():
    vbox:
        align (0.5, 0.82)
        text ">>> 外部端末に接続中... <<<" color "#00ff41" size 22 xalign 0.5
        null height 10
        textbutton "[ さくら医療研究センター 内部アーカイブ へアクセス ]":
            action Function(webbrowser.open, "https://sakurahospital.blogspot.com/")
            text_size 28
            text_color "#00ff41"
            text_hover_color "#ffffff"

# ==========================================
# メインストーリー開始ポイント
# ==========================================
label start:
    $ ui_phase = 1

    menu:
        "【デバッグ用ショートカット】"
        "通常通り最初からプレイする（第1部 / 名前入力から）":
            pass
        "第2部（事件の真相）から開始する":
            $ ui_phase = 2
            jump part2
        "第3部（謎解きと過去改変）から開始する":
            $ ui_phase = 3
            jump part3

    jump part1