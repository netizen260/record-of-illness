# ==========================================
# アセット定義ファイル (Summer Pockets風の構造管理)
# ==========================================

init python:
    # 時間帯管理用フラグ (a:昼, e:夕, n:夜)
    # ※現在はすべて同じ画像を参照しますが、将来差分が追加された場合に対応可能です。
    time_of_day = "a"

# ==========================================
# 背景 (Backgrounds)
# ==========================================
# 時間帯によって自動で切り替わる背景システム（例）
# 現在は差分がないため、どの時間帯でも同じ画像を表示します。
image bg corridor = ConditionSwitch(
    "time_of_day == 'a'", Transform("images/bg/corridor.png", size=(1920, 1080)),
    "time_of_day == 'e'", Transform("images/bg/corridor.png", size=(1920, 1080)),
    "time_of_day == 'n'", Transform("images/bg/corridor.png", size=(1920, 1080)),
    "True", Transform("images/bg/corridor.png", size=(1920, 1080))
)

image bg door = ConditionSwitch(
    "time_of_day == 'a'", Transform("images/bg/door.png", size=(1920, 1080)),
    "time_of_day == 'e'", Transform("images/bg/door.png", size=(1920, 1080)),
    "time_of_day == 'n'", Transform("images/bg/door.png", size=(1920, 1080)),
    "True", Transform("images/bg/door.png", size=(1920, 1080))
)

image bg hospitalroom = ConditionSwitch(
    "time_of_day == 'a'", Transform("images/bg/Hospitalroom.png", size=(1920, 1080)),
    "time_of_day == 'e'", Transform("images/bg/Hospitalroom.png", size=(1920, 1080)),
    "time_of_day == 'n'", Solid("#111122"),
    "True", Transform("images/bg/Hospitalroom.png", size=(1920, 1080))
)

image bg hospitalroom_night = Transform("images/bg/Hospitalroom_night.png", size=(1920, 1080))

image bg beach = Transform("images/bg/beach.png", size=(1920, 1080))
image bg lobby_day = Transform("images/bg/lobby.png", size=(1920, 1080))
image bg lab_east = Transform("images/bg/lab.png", size=(1920, 1080))
image bg corridor_noon = Transform("images/bg/corridor_noon.png", size=(1920, 1080))
image bg corridor_night = Transform("images/bg/corridor_night.png", size=(1920, 1080))

image bg corridodoor = Transform("images/bg/corridodoor.png", size=(1920, 1080))
image bg dennouroom = Transform("images/bg/dennouroom.png", size=(1920, 1080))


# イベントCG / サブ画像 (Event/Sub)
image sub1 = Transform("images/ev/sub1.png", size=(1920, 1080))
image sub2 = Transform("images/ev/siorimemo.png", size=(1920, 1080))
image carrying_mio = Transform("images/ev/carrying_mio.png", xalign=0.85, yalign=0.5, zoom=0.7)

image sub3 = Transform(Solid("#333333"), size=(1920, 1080))
image sub4 = Transform(Solid("#222222"), size=(1920, 1080))
image suffering_people = Transform(Solid("#111111"), size=(1920, 1080))
image ev_siori = Transform(Solid("#222233"), size=(1920, 1080))


# 第3部：コラージュ背景
image bg part3_bg = Composite(
    (1920, 1080),
    (0, 0),      Solid("#0f0000"),
    (15, 20),    Transform("images/ev/sub1.png", zoom=0.30),
    (1070, 15),  Transform("sub4", zoom=0.29),
    (1050, 360), Transform("images/ev/siorimemo.png", zoom=0.26),
    (0, 0),      Transform(Solid("#330000"), alpha=0.55),
)

# 基本色
image white = Solid("#ffffff")
image white2 = Solid("#ffffff")
image black = Solid("#000000")

# ==========================================
# キャラクター (Characters)
# ==========================================
# Base transforms
transform char_base:
    yanchor 1.0 ypos 1.0 zoom 0.8

# レイ先生と表情差分
image rei = At("images/char/rei.png", char_base)
image rei normal = At("images/char/rei.png", char_base)
image rei yawn = At("images/char/rei_yawn.png", char_base)
image rei smirk = At("images/char/rei_smirk.png", char_base)
image rei serious = At("images/char/rei_serious.png", char_base)
image rei surprised = At("images/char/rei_surprised.png", char_base)

# しおりと表情差分
image shiori = At("images/char/shiori.png", char_base)
image shiori normal = At("images/char/shiori.png", char_base)
image shiori smile = At("images/char/shiori_smile.png", char_base)
image shiori sad = At("images/char/shiori_sad.png", char_base)
image shiori blank = At("images/char/shiori_blank.png", char_base)
image shiori cry = At("images/char/shiori_cry.png", char_base)
image shiori serious = At("images/char/shiori.png", char_base)
image shiori casual smile = At("images/char/shiori_casual_smile.png", char_base)

# 電脳世界版しおり
image shiori_e01 = At("images/char/shioriE01.png", char_base)
image shiori_e02 = At("images/char/shioriE02.png", char_base)

# 佐倉院長
image sakura = At("images/char/sakura.png", char_base)
image sakura normal = At("images/char/sakura.png", char_base)

# 旧名との互換性
image shioriE01 = "shiori_e01"
image shioriE02 = "shiori_e02"

# ==========================================
# カスタムトランジション・エフェクト
# ==========================================

# ゆっくりとしたディゾルブ（商業風の余韻）
define slow_dissolve = Dissolve(1.5)
define flash_dissolve = Fade(0.1, 0.0, 0.5, color="#fff")

# グリッチ演出用ディゾルブ
define glitch_dissolve = MultipleTransition([
    False, Dissolve(0.1),
    Solid("#000000"), Pause(0.1),
    Solid("#ffffff"), Dissolve(0.1),
    True])

# 画面揺れ用のトランスフォーム (script.rpyから移動)
transform glitch_shake:
    linear 0.05 xoffset 10 yoffset 5
    linear 0.05 xoffset -15 yoffset -10
    linear 0.05 xoffset 5 yoffset 15
    linear 0.05 xoffset -10 yoffset -5
    linear 0.05 xoffset 0 yoffset 0
    repeat

# UI用の微弱なグリッチエフェクト
transform glitch_ui_shake:
    choice:
        pause 2.0
    choice:
        pause 5.0
    choice:
        pause 3.5
    linear 0.05 xoffset 3
    linear 0.05 xoffset -3
    linear 0.05 xoffset 0
    repeat
