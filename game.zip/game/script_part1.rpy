# 第1部：表向きのシナリオ

label part1:
    $ ui_phase = 1
    stop music fadeout 2.0
    scene black with dissolve

    $ player_name = renpy.input("プレイヤーネームを入力してください。", default="主人公")
    $ player_name = player_name.strip()
    if not player_name:
        $ player_name = "主人公"
        
    if player_name in ["澤部", "澤部 燈真", "澤部燈真"]:
        # 特定の名前が入力された場合はハッキング演出と共に第2部へ移行
        play sound "audio/SE/noise_tv.mp3"
        show sandstorm_bg zorder 100
        pause 1.0
        hide sandstorm_bg
        call screen fake_loading_screen
        jump part2
        
    elif player_name in ["瑞浪", "瑞浪 みお", "瑞浪みお"]:
        # しおりの本名が入力された場合はハッキング演出と共に第3部へ移行
        play sound "audio/SE/noise_tv.mp3"
        show sandstorm_bg zorder 100
        pause 1.0
        hide sandstorm_bg
        call screen fake_loading_screen
        jump part3

    scene bg corridodoor with dissolve
    play music "audio/BGM/01_hospital_daily.mp3" fadein 2.0 fadeout 2.0
    m "（……よし、今日から俺が彼女の専属担当だ）"
    "日食病――急激な眠気から始まり、やがて長期の昏睡へと至る原因不明の意識障害。"
    "進行に伴って、患者の記憶や感情も真っ白に失われていくと言われている、恐ろしい病気だ。"
    "この『さくら医療研究センター』に来てから数々の患者を見てきたが、今日から担当するのは、まだ十四歳の少女だった。"
    "不安を悟られないよう、俺は口角を上げて笑顔を作る練習を繰り返した。"
    play sound "audio/SE/knock.mp3"
    pause 0.5
    "コンコン"
    m "失礼します。今日から担当になった、研究員の[player_name]です"
    play sound "audio/SE/dooropen.mp3"
    pause 0.5
    scene bg door with dissolve
    show rei yawn at center with dissolve
    r "おや、意外と早かったな……ふぁあ"
    "主任のレイ先生だ。大あくびをして、眠そうに目をこすっている。"
    m "レイ先生！？ どうしてここに？ というか白衣シワシワですよ、また徹夜ですか？"
    show rei normal at center with dissolve
    r "前任者の私がいないわけにはいかないだろう？ 大切な日にね"
    r "……それに、昨日の夜からずっとこの病室でカルテの整理をしていたからな。そろそろ足腰の限界だ"
    m "えっ、昨夜からずっと病室に！？ というか、なんで患者の病室で仕事してるんですか！ 患者さんの迷惑ですから、早く帰って寝てください！"
    show rei smirk with dissolve
    r "真の研究者にとって、研究は時間と場所を選ばないものだ"
    r "ほら、立ち話をしていても患者を待たせるだけだ。早く入りたまえ"
    "（いや、時間と場所を選ばないって……患者の病室はさすがに選んでくださいよ……！）"

    play music "audio/BGM/haruemukaukusabanae.mp3" fadein 2.0 fadeout 2.0
    "俺はレイ先生に促されるまま、病室の中へと足を踏み入れた。"
    play sound "audio/SE/足音・革靴01_1.5x.mp3"
    pause 1.0
    


    scene bg hospitalroom with fade
    show rei normal at center with dissolve
   
    r "しおり、紹介する。彼が今日から君の担当医になる[player_name]だ"
    show shiori normal at right with dissolve
    s "……新しい、先生……？"
    
    "不安に揺れる声で、彼女はすがるようにレイ先生を見上げた。"
    r "心配しなくていい、彼は優秀だ。それに……"
    r "彼はこの病院で唯一、白衣に『お花畑の香りの柔軟剤』を使うような軟弱な男だからな。ガサツな私より、よっぽど君の話し相手に適任だろう"
    with hpunch
    m "レイ先生！ 初対面のどんな紹介の仕方ですか！"
    m " だいたい、柔軟剤くらい普通使いますよ！"
    
    r "真の研究者はそんな無駄な香料など気にしない。だから君は、いつまで経っても万年助手どまりなのだよ"
    r "まあ、そういう隙だらけの男の方が、君も肩の力を抜けるはずだ"
    m "隙だらけってなんですか！ それに、白衣が柔らかいと、思考も柔軟になるんです！"
    r "君の思考は柔軟を通り越して、ただのフニャフニャだ。綿菓子と同レベルだな"
    m "綿菓子は甘くて人を幸せにします！ 幸せな研究者は良い成果を出すんです！"
    r "屁理屈だけは一人前だな。……おや"
    play sound "audio/SE/通知音.mp3"
    show rei surprised  
    r "院長室から呼び出しだな。……では、後は二人に任せるよ"
    play sound "audio/SE/足音・革靴01_1.5x.mp3"
    hide rei with dissolve
    show shiori normal at center with dissolve
    m "あー……しおりちゃん。改めてよろしく、[player_name]です"
    m "レイ先生と違って常識はあるから心配しないでね"
    show shiori smile with dissolve
    s "ふふっ"
    m "急に担当医が変わって混乱してるかもしれないけど、君の話し相手にって、僕を指名してくれたんだ。"
    m "だから、不安に思わないでね"
    show shiori normal with dissolve
    s "レイ先生、いつも難しい顔をしてるけど……本当は、私のことをすごく気にかけてくれてるんだよね"
    m "うん。レイ先生は口下手だから勘違いされやすいけど、本当はすごく優しい先生なんだよ"
    s "うん、知ってる。言葉にしないだけで……担当が変わって私が不安にならないように、昨日も私のそばにいてくれたんだと思う"
    "（……あ。あの人の『徹夜』って、そういうことだったのか）"
    "（本当に不器用な人だな……。でも、だからって患者の部屋で仕事するなよな）"
    "しおりちゃんはゆっくりと顔を上げ、俺の目をじっと見つめた。そして、少しだけはにかむように微笑んだ。"
    show shiori smile with dissolve
    s "[player_name]先生、新しい先生が、優しいそうな人でよかった"
    m "僕もしおりちゃんの担当になれて嬉しいよ。何でも話してね"

    
    hide shiori
    show rei normal at center
    r "仲が深まったようで何よりだ"
    with vpunch
    m "レイ先生！？ なんで戻ってきてるんですか！"
    r "渡し忘れたものがあってな。ほら、君の新任祝いだ"
    "レイ先生は俺の胸ポケットに、無骨な黒い万年筆を押し込んだ。"
    r "ではな"
    play sound "audio/SE/足音・革靴01_1.5x.mp3"
    hide rei with dissolve
    pause 1.0
    
    m "はは……本当に嵐みたいな人だね"
    show shiori smile at center with dissolve
    s "ふふっ"
    "病室の張り詰めていた空気が、一気に和らいでいく。"
    s "レイ先生、いつもお仕事が忙しそうなの"
    s "難しい紙ばかり見ていたから……話しかけるの、ちょっと遠慮しちゃってたんだ"
    m "……そっか。これからは僕が毎日来くから寂しい思いはさせないよ"
    show shiori normal with dissolve
    s "寂しくない……か"
    s "ねえ、先生。外の世界には……『寂しいと死んじゃうウサギさん』が、本当に山ほどいるの？"
    m "え？ いや、ウサギは別に寂しくても死なないよ。あれは嘘だからね。誰からそんな話を……？"
    s "レイ先生。私が一人で寂しくしていた時に、急に入ってきて……『お前もウサギと同じだ。寂しさでバイタルが低下する』って、真顔でモニターを睨みながら"
    m "あの人、患者に嘘を吹き込まないでほしいんだけど……"
    m "あれは、ただの都市伝説なんだよ"
    m "一説では、ペット業界がウサギを二羽セットで購入させるためのマーケティング戦略で言われ始めただけとか"
    show shiori smile with dissolve
    s "……本当？ よかった。じゃあ、寂しくて死んじゃうウサギさんはいないんだね。"
    s "先生。これから外のお話、たくさんたくさん聞かせてね"
    m "もちろん！ ウサギの本当の生態から、海の話、山の話まで何でもござれだ！"
    s "うん！ ……うふふ、なんだか嬉しいな……"
    show shiori sad with dissolve
    s "……でも私、なんだか急に眠くなっちゃった……"
    "（……急な眠気？ ブランカの副作用だろうか……？）"
    "しおりちゃんは少し眠そうに目をこすり、ベッドに横になった。"
    m "ゆっくり休んで。明日もまた、ここに来るから"
    s "うん……おやすみなさい、[player_name]先生……"
    hide shiori with dissolve
    scene black with dissolve
    scene black with dissolve
    "――それから、数週間が過ぎた。"
    "俺としおりちゃんの時間は、穏やかに流れていた。"
    "外の世界の出来事、見たこともない街の景色。俺が語るすべてを、彼女は楽しそうに聞いてくれた。"
    scene bg hospitalroom with dissolve
    show shiori smile with dissolve
    s "ふふ、先生の白衣、今日もいい匂いがする。……ずっと嗅いでいたいな"
    m "ははは、あまり嗅ぐと鼻がお花畑になっちゃうよ？"
    s "それでもいいよ。だって、病院の消毒の匂い、ちょっと冷たくて苦手だから……"
    "しおりちゃんが少し眉をひそめ、耳元を押さえた。"
    stop music fadeout 1.0
    show shiori sad with dissolve
    s "っ……"
    m "しおりちゃん？ どうしたの？ 気分が悪い？"
    s "うううん、大丈夫……。ただ、窓の外の光が、一瞬だけ……目が痛くなるくらい強く見えた気がして"
    s "それに、あの機械の音が、いつもより頭の中に響くような……"
    m "光と音……. 少し疲れが出たのかな？ 無理しちゃだめだよ"
    show shiori normal with dissolve
    play music "audio/BGM/01_hospital_daily.mp3" fadein 2.0 fadeout 2.0
    s "ううん、もう平気！ 先生とお話ししてたら、眩しいのも耳鳴りもどこかに行っちゃった。ねえ先生、さっきの海の波の話、もっと聞かせて？"
    m "……うん。でも、少しでもしんどくなったら、すぐに言うんだよ？"
    s "うん！"
    scene black with dissolve
    play music "audio/BGM/03_hospital_pretend.mp3" fadein 2.0 fadeout 2.0
    "この日々が、永遠に続くのだと。……そんな傲慢な錯覚を、俺は抱いていたんだ。"
    "しおりちゃんの身に起きていた小さな異変に、どうしてあの時、もっと早く気づけなかったのだろう。"
    scene bg hospitalroom with dissolve
    m "しおりちゃん、来たよ。起きてる？ 調子は……どう？"
    "病室に入ると、しおりちゃんはベッドの上で窓の外を向いたまま、ぴくりとも動かなかった。"
    "部屋の中に、不気味な静寂が広がる。"
    m "しおりちゃん……？"
    s "……"
    show shiori blank at center with dissolve
    "しおりちゃんがゆっくりと振り返る。だが、その瞳に焦点は合っていなかった。"
    s "……あの。……あなたは、どなたですか？"
    m "え……？"
    
    "心臓を鷲掴みにされたように胸が痛み、息が詰まる。"
    show shiori blank at right with move
    show rei normal at left with dissolve
    r "無駄だよ。日食病の進行が進んで、記憶がどんどん抜け落ちているんだ"
    m "レイ先生！ これはいったい……！ 治療法はないんですか……！？"
    r "病が彼女の記憶を、感情を、真っ白に消し去っていく。……君という存在の記憶も、彼方へ消えた"
    m "そんな……昨日、あんなに笑って……いつか外へ行く約束だってしたのに！"
    r "……楽しい思い出という『光』が強ければ強いほど、それが欠け落ちた時の虚無――すなわち『日食』の闇は深くなる。それが、この病の残酷なところだ"
    hide rei with dissolve
    show shiori blank at center with move
    "残された俺は、名前すら忘れてしまった少女の前で、ただ立ち尽くすことしかできなかった。"
    scene black with dissolve
    "さらに数日が過ぎた。"
    "しおりちゃんの容体は急速に悪化し、俺たちは最大の正念場を迎えていた。"
    "日食病の浸食は深く、彼女の意識は深い闇の底へと沈みかけていた。"
    "けれど、俺たちは諦めなかった。"
    scene bg corridor_noon with dissolve
    play music "audio/BGM/04_consultation.mp3" fadein 2.0 fadeout 2.0
    show rei normal at center with dissolve
    m "レイ先生、なんとかならないんですか！？ 彼女をこのままにしておくわけには……！"
    r "……脳への負荷が限界に近い。ご家族の同意が必要だが、新しく開発された『血液浄化療法』の緊急手術を実施する"
    r "体内で悪さをする異常な成分を物理的に除去する手術だ。成功確率は決して高くはないが、今の彼女にはこれにかけるしかない"
    r "ご家族への連絡と同意書の手続きは君が進めておいてくれ。私はすぐに手術の準備に入る。術後は君が付きっきりで支えてやるんだ"
    m "はい！ よろしくお願いします！"
    hide rei with dissolve
    "緊迫した雰囲気の中、長時間の血液浄化手術が行われた。"
    "手術は成功したものの、しおりちゃんの意識はまだ戻らなかった。"
    scene bg hospitalroom_night with dissolve
    "俺はしおりちゃんの小さな手を、両手で包み込むように握りしめた。"
    m "頼む、目を開けてくれ、しおりちゃん……。まだ約束を果たしていないだろう？"
    "彼女が眠る間も、俺は片時も離れず、静かに他愛のない話を語りかけ続けた。"
    "静かな病室に、規則正しいバイタルモニターの音と、俺の呼びかける声だけが響いていた。"
    "数日後の朝――"
    with vpunch
    play music "audio/BGM/05_hope.mp3" fadein 2.0 fadeout 2.0
    "握りしめていた指先に、かすかに温かな力が戻るのを、俺は感じた。"
    scene bg hospitalroom with dissolve
    show shiori normal at center with dissolve
    s "……あ……[player_name]……先生……？"
    m "しおりちゃん！？ わかるのか……！？"
    s "うん……。なんだか、すごく長い、暗い夢を見ていたみたい……"
    s "底なしの暗闇の中でね、先生の優しい声がずっと聞こえてたの……。先生のお花畑の匂いもして、私をずっと呼んでくれて……だから、戻ってこられたよ"
    show shiori smile with dissolve
    m "よかった……！ 本当によかった……っ！"
    "俺の目からこぼれた涙を見て、しおりちゃんは愛おしそうに微笑んだ"
    s "ふふ、先生、泣き虫さんだね。……もう大丈夫だよ"
    scene white with Dissolve(2.0)
    pause 2.0

    scene bg lobby_day with dissolve
    
    "――それから、数ヶ月後。"
    "驚異的な回復を見せたしおりちゃんは、ついに退院の日を迎えた。"
    "さくら医療研究センターのロビーは、今日の彼女の門出を祝うように温かな光に満ちていた。"
    show shiori casual smile at center with dissolve
    s "先生！ お待たせしました！"
    "病室にいた頃が嘘のように、彼女は元気いっぱいに駆け寄ってきた。"
    m "しおりちゃん、退院おめでとう。本当に頑張ったね"
    s "えへへ、先生とレイ先生が助けてくれたおかげだよ。あ、レイ先生は？"
    m "『真の研究者は見送りなどという非生産的なことはしない』って言って、研究室にこもっちゃったよ"
    s "ふふ、相変わらず不器用な先生だなぁ。後でお礼の手紙、ポストに入れておくね"
    m "うん、きっと喜ぶよ。……さあ、行こうか。約束していた場所へ"
    s "うん"
    scene bg beach with dissolve
    s "わあ……！ すごい……！ 先生、見て、本当にキラキラ輝いてる……！"
    "しおりちゃんは目を輝かせて、目の前に広がる水平線を見つめていた。"
    m "綺麗だね、しおりちゃん。約束、守れてよかった"
    s "うん！ 先生が病室で話してくれた波の音、本物はもっと素敵だね。連れてきてくれてありがとう、先生"
    "しおりちゃんは俺の手をごく自然に握りしめ、最高の笑顔を向けた。"
    s "私、これからもっともっと、たくさんの世界を見て回るんだ。先生も、一緒にいてくれるよね？"
    m "ああ、もちろんだよ。どこまでも一緒に行こう"
    "二人は手をつないだまま、新しい一歩を踏み出した。"
    scene black with dissolve
    "―― 『日食病』闘病記録 完 ――"
    "作成者：しおり"
    "制作：さくら医療研究センター 広報部"
    "作成協力：澤部 燈真 医師"
    "本作品は、患者様の認知機能回復リハビリテーションの成果発表として、ホームページ上に掲載しております"
    scene black with dissolve
    pause 2.0
    return
