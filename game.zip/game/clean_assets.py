import os
import shutil
import re

# 検索対象のディレクトリ
GAME_DIR = os.path.dirname(os.path.abspath(__file__))
AUDIO_DIR = os.path.join(GAME_DIR, "audio")
IMAGES_DIR = os.path.join(GAME_DIR, "images")

# RPYファイルの読み込み
rpy_files = [os.path.join(GAME_DIR, f) for f in os.listdir(GAME_DIR) if f.endswith(".rpy")]
rpy_content = ""
for rpy_path in rpy_files:
    with open(rpy_path, "r", encoding="utf-8") as f:
        rpy_content += f.read()

# 画像と音声の物理ファイルを再帰的にスキャン
asset_files = []
for root, dirs, files in os.walk(IMAGES_DIR):
    # 'old' フォルダや 'original_assets' はスキャンから除外
    if "old" in root or "original_assets" in root:
        continue
    for file in files:
        full_path = os.path.join(root, file)
        rel_path = os.path.relpath(full_path, GAME_DIR).replace("\\", "/")
        asset_files.append((full_path, rel_path, file))

for root, dirs, files in os.walk(AUDIO_DIR):
    if "old" in root:
        continue
    for file in files:
        full_path = os.path.join(root, file)
        rel_path = os.path.relpath(full_path, GAME_DIR).replace("\\", "/")
        asset_files.append((full_path, rel_path, file))

# 各アセットがRPYファイルに記述されているかチェック
unused_assets = []
used_assets = []

for full_path, rel_path, filename in asset_files:
    # 拡張子なしのベース名と、相対パス、ファイル名で検索
    basename = os.path.splitext(filename)[0]
    
    # RPYファイル内で参照されているか確認
    # (例: "images/bg/corridor.png", "bg corridor", "corridor", "audio/knock.mp3" など)
    pattern = re.compile(
        re.escape(filename) + "|" +
        re.escape(basename) + "|" +
        re.escape(rel_path),
        re.IGNORECASE
    )
    
    if pattern.search(rpy_content):
        used_assets.append((rel_path, full_path))
    else:
        unused_assets.append((rel_path, full_path))

# 結果の出力とファイルの移動
print(f"=== アセット精査結果 ===")
print(f"使用中アセット数: {len(used_assets)}")
print(f"未使用アセット数: {len(unused_assets)}")

for rel_path, full_path in unused_assets:
    print(f"未使用検出: {rel_path}")
    
    # 移動先 'old' フォルダの作成
    dir_name = os.path.dirname(full_path)
    old_dir = os.path.join(dir_name, "old")
    if not os.path.exists(old_dir):
        os.makedirs(old_dir)
        
    dest_path = os.path.join(old_dir, os.path.basename(full_path))
    try:
        shutil.move(full_path, dest_path)
        print(f"-> [SUCCESS] Move: {rel_path} -> {os.path.relpath(dest_path, GAME_DIR).replace('\\', '/')}")
    except Exception as e:
        print(f"-> [FAIL] Move: {rel_path} ({e})")

# 'images/char/original_assets' など、明らかに不要なサブフォルダも old フォルダに整理する
char_orig_dir = os.path.join(IMAGES_DIR, "char", "original_assets")
if os.path.exists(char_orig_dir):
    char_old_dir = os.path.join(IMAGES_DIR, "char", "old", "original_assets")
    if not os.path.exists(os.path.dirname(char_old_dir)):
        os.makedirs(os.path.dirname(char_old_dir))
    try:
        shutil.move(char_orig_dir, char_old_dir)
        print(f"-> [SUCCESS] Move original_assets to old")
    except Exception as e:
        print(f"-> [FAIL] Move original_assets: {e}")


print("=== 精査終了 ===")
